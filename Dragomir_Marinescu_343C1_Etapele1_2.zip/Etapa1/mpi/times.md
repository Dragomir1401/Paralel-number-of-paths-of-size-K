MPI:

small: -8: 1.2424 seconds
       -16: 2.65544 seconds
medium: -8: 3.42033 seconds
        -16: 5.35 seconds
large:  -8: 7.87784 seconds
        -16: 10.9679 seconds

Serial:

small: 24.9444 seconds
medium: 95.2735 seconds
large: 220.889 seconds