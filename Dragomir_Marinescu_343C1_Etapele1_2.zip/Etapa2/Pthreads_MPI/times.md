Hybrid:

Small:
- 8 threads, 8 processes:   6.13678 seconds
- 8 threads, 16 processes:  14.1339 seconds
- 16 threads, 8 processes:  7.14966 seconds
- 16 threads, 16 processes: 13.3686 seconds

Medium:
- 8 threads, 8 processes:   23.5527 seconds
- 8 threads, 16 processes:  48.2324 seconds
- 16 threads, 8 processes:  21.6512 seconds
- 16 threads, 16 processes: 42.3643 seconds

Large:
- 8 threads, 8 processes:   51.5139 seconds
- 8 threads, 16 processes:  115.14 seconds
- 16 threads, 8 processes:  50.6849 seconds
- 16 threads, 16 processes: 104.953 seconds

Serial:

small: 24.9444 seconds
medium: 95.2735 seconds
large: 220.889 seconds
